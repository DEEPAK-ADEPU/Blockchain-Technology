const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const cors = require('cors');

const app = express();
app.use(bodyParser.json());
app.use(cors());

const db = mysql.createConnection({
  host: 'localhost',
  port: 3306,
  user: 'root',
  password: '4876',
  database: 'DeBank'
});

db.connect(err => {
  if (err) {
    console.error('Error connecting to MySQL database:', err.message);
    return;
  }
  console.log('Connected to MySQL database using caching_sha2_password.');
});

app.post('/register', (req, res) => {
  const { email, password, username } = req.body;
  bcrypt.hash(password, 10, (err, hash) => {
    if (err) {
      return res.status(500).json({ error: 'Failed to hash password' });
    }
    const sql = 'INSERT INTO users (email, password, username) VALUES (?, ?, ?)';
    db.execute(sql, [email, hash, username], (err, result) => {
      if (err) {
        return res.status(500).json({ error: 'Failed to register user' });
      }
      res.status(200).json({ message: 'User registered successfully!' });
    });
  });
});

app.post('/login', (req, res) => {
  const { email, password } = req.body;
  const sql = 'SELECT * FROM users WHERE email = ?';
  db.execute(sql, [email], (err, result) => {
    if (err) {
      return res.status(500).json({ error: 'Failed to retrieve user data' });
    }
    if (result.length === 0) {
      return res.status(400).json({ error: 'User not found' });
    }
    bcrypt.compare(password, result[0].password, (err, isMatch) => {
      if (err) {
        return res.status(500).json({ error: 'Password comparison failed' });
      }
      if (!isMatch) {
        return res.status(400).json({ error: 'Invalid password' });
      }
      res.status(200).json({
        message: 'Login successful',
        username: result[0].username
      });
    });
  });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}/`);
});
