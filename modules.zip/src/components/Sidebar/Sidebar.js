import React from 'react';
import '../Dashboard/dashboard.css';


const Sidebar = () => {
  
  return (
    <div className="app-body-navigation">
    <nav className="navigation">
      <a href="/dashboard">
        <i className="ph-browsers" class="active"></i>
        <span>Home</span>
      </a>
      <a href="/payment">
        <i className="ph-swap"></i>
        <span>Pay to UPI ID</span>
      </a>
      <a href="#">
        <i className="ph-file-text"></i>
        <span>Invest</span>
      </a>
      <a href="/governance">
        <i className="ph-globe"></i>
        <span>Governance</span>
      </a>
      <a href="/GetLoan">
        <i className="ph-check-square"></i>
        <span>Get loan</span>
      </a>
      <a href="#">
        <i className="ph-clipboard-text"></i>
        <span>Insights</span>
      </a>
      <a href="#">
        <i className="ph-globe"></i>
        <span>Explore</span>
      </a>
    </nav>
  </div>
  );
}

export default Sidebar;