import React, { useState } from 'react';
import Header from '../Header/Header.js';
import './Payment.css';
import Sidebar from '../Sidebar/Sidebar.js';

const Payment = () => {
  const [upiId, setUpiId] = useState('');
  const [Amount, setAmount] = useState('');
  const [bank, setBank] = useState('');
  const [transactions, setTransactions] = useState([
    { name: 'DMart', amount: 2393 },
    { name: 'Electricity Bill', amount: 1490 }
  ]);

  const processPayment = () => {
    if (!upiId || !bank || !Amount) {
      alert('Please fill in all fields');
      return;
    }

    const newTransaction = {
      name: upiId.split('@')[0],
      amount: parseFloat(Amount)
    };

    setTransactions([newTransaction, ...transactions]);
    setUpiId('');
    setBank('');
    setAmount('');
  };

  return (
    <div className='payment-section'>
      <Header />
      <div className='payment-sub-section'>
        <Sidebar />
        <div className='payment-sub-section-2'>
          <div className="container">
            <div className="payment-form">
              <h2>UPI Payment</h2>
              <input
                type="text"
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                placeholder="Enter UPI ID"
              />
              <input
                type="text"
                value={Amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter Amount"
              />
              <select
                value={bank}
                onChange={(e) => setBank(e.target.value)}
              >
                <option value="">Select Bank</option>
                <option value="SBI">SBI</option>
                <option value="Federal Bank">Federal Bank</option>
              </select>
              <button onClick={processPayment}>Pay</button>
            </div>
            <div className="transaction-history">
              <h2>Transaction History</h2>
              <ul>
                {transactions.map((transaction, index) => (
                  <li key={index}>
                    <span>{transaction.name}</span>
                    <span>₹{transaction.amount}</span> 
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Payment;
