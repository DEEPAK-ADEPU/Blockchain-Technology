import React, { useState } from 'react';
import Cookies from 'js-cookie'; 
import styles from './Header.module.css';

const Header = () => {
  const [showLogout, setShowLogout] = useState(false); 
  const username = Cookies.get('username'); 

  const handleLogout = () => {
    Cookies.remove('username'); 
   
    window.location.reload(); 
  };

  return (
    <header className={styles.appHeader}>
      <div className={styles.appHeaderLogo}>
        <div className={styles.logo}>
          <span>
            <img
              src="https://i.pinimg.com/originals/f2/5b/2b/f25b2b0a75139fdeae6e93a57cf82c31.png"
              alt="Logo"
              className={styles.logoIcon}
            />
          </span>
          <h1 className={styles.logoTitle}>
            <span className={styles.logoTitleSpan1}>AD</span>
            <span className={styles.logoTitleSpan2}>DeBank</span>
          </h1>
        </div>
      </div>
      <div className={styles.appHeaderActions}>
        <button 
          className={styles.userProfile} 
          onClick={() => setShowLogout(!showLogout)} 
        >
          <span>{username ? username : 'Guest'}</span>
          <span>
            <img
              src="https://assets.codepen.io/285131/almeria-avatar.jpeg"
              alt="User Avatar"
              className={styles.userAvatar}
            />
          </span>
        </button>
        {showLogout && (
          <div className={styles.logoutMenu}>
            <button className={styles.logoutButton} onClick={handleLogout}>
              Logout
            </button>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
