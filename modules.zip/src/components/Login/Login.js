import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Cookies from 'js-cookie';
import styles from './Login.module.css';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:3001/login', {
        email,
        password,
      });

  
      const { username } = res.data;
      
      
      Cookies.set('username', username, { expires: 30 });

      navigate('/dashboard');
    } catch (error) {
      console.error(error.response?.data?.message || 'Login failed.'); 
    }
  };

  const onClickSignUp = () => {
    navigate('/register');
  };

  return (
    <div className={styles.loginContainer}>
      <div className={styles.loginBox}>
        <h2>Login To DeBank</h2>
        <form onSubmit={handleSubmit}>
          <div className={styles.inputGroup}>
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className={styles.inputGroup}>
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <div className={styles.inputGroup}>
            <button type="submit">Login</button>
          </div>
          <div className={styles.extraLinks}>
            <button type="button">Forgot Password?</button>
            <br />
            <button type="button" onClick={onClickSignUp}>Sign Up</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;
