import React from 'react';
import Header from '../Header/Header.js';
import './Governance.css';
import Sidebar from '../Sidebar/Sidebar.js'
import { Navigate, useNavigate } from 'react-router-dom';


const Governance = () => {
    const navigate = useNavigate();

    const onClickProposal = () => {
        navigate('./proposals');
    }
  
  return (
    <div className='governance-bg-container'>
      <Header />
      <div className='governance-sub-bg-container'>
            <Sidebar />
            <div class="MaintableDiv">
                <div class="header">
                    <h2>Proposals</h2>
                </div>
                <div class="proposals-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Voted</th>
                                <th>Status</th>
                                <th>Results</th>
                                <th>Start</th>
                                <th>End</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="eachRow" onClick={onClickProposal}>
                                <td>Loan For Mukesh Ambani<br/><span>Standard DAO Proposal</span></td>
                                <td>-</td>
                                <td><span class="status active">Active</span></td>
                                <td>-</td>
                                <td> October 20, 2024<br/><span>20:13 PM</span></td>
                                <td> November 10, 2024<br/><span>21:39 PM</span></td>
                            </tr>
                            <tr class="eachRow"  >
                                <td>Interest Rate Hike<br/><span>Standard DAO Proposal</span></td>
                                <td>-</td>
                                <td><span class="status completed">Completed</span></td>
                                <td><div class="result-bar"><div class="bar completed"></div></div></td>
                                <td>August 01, 2024<br/><span>20:14 PM</span></td>
                                <td>August 21, 2024<br/><span>20:46 PM</span></td>
                            </tr>
                            <tr class="eachRow">
                                <td> Funding a statrtup<br/><span>Standard DAO Proposal</span></td>
                                <td>-</td>
                                <td><span class="status completed">Completed</span></td>
                                <td><div class="result-bar"><div class="bar completed"></div></div></td>
                                <td> September 8, 2024<br/><span>20:14 PM</span></td>
                                <td> September 28, 2024<br/><span>20:46 PM</span></td>
                            </tr>
                            <tr class="eachRow">
                                <td> Voting power for FD <br/><span>Standard DAO Proposal</span></td>
                                <td>-</td>
                                <td><span class="status completed">Completed</span></td>
                                <td><div class="result-bar"><div class="bar completed"></div></div></td>
                                <td>April 01, 2024<br/><span>20:14 PM</span></td>
                                <td>April 21, 2024<br/><span>20:46 PM</span></td>
                            </tr>
                            <tr class="eachRow">
                                <td>Loan For Mukesh Ambani<br/><span>Standard DAO Proposal</span></td>
                                <td>-</td>
                                <td><span class="status completed">Completed</span></td>
                                <td><div class="result-bar"><div class="bar completed"></div></div></td>
                                <td>August 01, 2024<br/><span>20:14 PM</span></td>
                                <td>August 04, 2024<br/><span>20:46 PM</span></td>
                            </tr>
                            <tr class="eachRow">
                                <td>Loan For Mukesh Ambani<br/><span>Standard DAO Proposal</span></td>
                                <td>-</td>
                                <td><span class="status completed">Completed</span></td>
                                <td><div class="result-bar"><div class="bar completed"></div></div></td>
                                <td>August 01, 2024<br/><span>20:14 PM</span></td>
                                <td>August 04, 2024<br/><span>20:46 PM</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
       </div> 
    <div/>
        
    </div>
  );
}

export default Governance;