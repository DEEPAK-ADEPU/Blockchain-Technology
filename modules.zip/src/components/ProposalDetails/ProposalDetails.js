import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer } from 'recharts';
import { ArrowRight, Check } from 'lucide-react';
import './ProposalDetails.css';
import Header from '../Header/Header';
import Sidebar from '../Sidebar/Sidebar';


const contractABI = [
    
    {
        "inputs": [{"internalType": "string","name": "_description","type": "string"},{"internalType": "uint256","name": "_duration","type": "uint256"}],
        "name": "createProposal",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [{"internalType": "uint256","name": "_proposalId","type": "uint256"},{"internalType": "bool","name": "_support","type": "bool"}],
        "name": "vote",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [{"internalType": "uint256","name": "_proposalId","type": "uint256"}],
        "name": "executeProposal",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    }
];
const contractAddress = '0xCFA6d40AC9b8B2EB888Ef5725bdb62ac8553a9E7';

const GovernanceProposal = () => {
  const [isWalletConnected, setIsWalletConnected] = useState(false);
  const [voteOption, setVoteOption] = useState(null);
  const [signer, setSigner] = useState(null);
  const [contract, setContract] = useState(null);

  
  const votingData = [
    { name: 'Fund ASR for 1 y...', value: 211096893, percentage: 69 },
    { name: 'Burn the tokens', value: 82035682, percentage: 27 },
    { name: 'Return to Community...', value: 14350755, percentage: 5 },
  ];

  const totalVotes = 307483434;

 
  const connectWallet = async () => {
    if (typeof window.ethereum !== 'undefined') {
      try {
        const provider = new ethers.BrowserProvider(window.ethereum);
        const _signer = await provider.getSigner();
        await provider.send("eth_requestAccounts", []);
        setSigner(_signer);
        setIsWalletConnected(true);

        const governanceContract = new ethers.Contract(contractAddress, contractABI, _signer);
        setContract(governanceContract);
      } catch (error) {
        console.error("Failed to connect to MetaMask", error);
      }
    } else {
      alert("MetaMask is not installed!");
    }
  };

  
  const handleVote = async () => {
    if (!isWalletConnected) {
      alert("Please connect your wallet first!");
      return;
    }
    if (!voteOption) {
      alert("Please select a voting option!");
      return;
    }

    
    try {
      const proposalId = 1; 
      const voteFor = voteOption === 'For';
      const tx = await contract.vote(proposalId, voteFor);
      await tx.wait();
      alert(`You voted ${voteOption}`);
    } catch (error) {
      console.error("Failed to vote", error);
      alert("Failed to cast vote");
    }
  };


  const handleAddProposal = async () => {
    if (!isWalletConnected) {
      alert("Please connect your wallet first!");
      return;
    }

    try {
      const description = "New Proposal";
      const duration = 3600;  
      const tx = await contract.createProposal(description, duration);
      await tx.wait();
      alert("Proposal created");
    } catch (error) {
      console.error("Failed to create proposal", error);
      alert("Failed to create proposal");
    }
  };

  return (
    <div className='proposal-bg-container'>
        <Header />
        <div className='proposal-sb-content'>
            <Sidebar />
            <div className="governance-proposal">
                <div className="proposal-grid">
                    <div className="proposal-details">
                    <div className="proposal-header">Governance &gt; Proposal</div>
                    <h2>Loan Proposal for Mr. Mukesh Ambani, Chairman of Reliance Industries Limited</h2>
                    <p>This proposal outlines a loan offering to Mr. Mukesh Ambani, one of India's leading business magnates and the Chairman of Reliance Industries Limited. Given his impeccable financial standing and the vast global reach of his company, this loan would not only be secure but also a beneficial partnership opportunity for the bank.</p>
                    <ol>
                        <li>Fund 1 more year of ASR with 50M per quarter (rest returned to community mulitisig)</li>
                        <li>Burn the tokens</li>
                        <li>Return the tokens to the community multisig</li>
                    </ol>
                    <p className="note">Note: This is the last vote with ASR Rewards for this quarter, claim your rewards in 2 weeks. Vote to continue this practice for future quarters.</p>
                    <button className="view-proposal">
                        View Full Proposal <ArrowRight size={16} />
                    </button>
                    </div>
                    <div className="voting-section">
                        <h3>Cast your vote</h3>
                        <p className="voting-power">Voting power: --</p>
                        <div className="voting-buttons">
                        <button 
                            onClick={() => setVoteOption('For')} 
                            className={`button vote-option ${voteOption === 'For' ? 'selected' : ''}`}
                        >
                            For
                        </button>
                        <button 
                            onClick={() => setVoteOption('Against')} 
                            className={`button vote-option ${voteOption === 'Against' ? 'selected' : ''}`}
                        >
                            Against
                        </button>
                        <button 
                            onClick={handleVote} 
                            className="button vote-submit"
                        >
                            Vote
                        </button>
                        </div>
                    </div>
                </div>
                <div className="voting-results">
                <h3>Results</h3>
                <p className="total-votes">{totalVotes.toLocaleString()} votes</p>
                <ResponsiveContainer width="100%" height={200}>
                    <BarChart layout="vertical" data={votingData}>
                    <XAxis type="number" hide />
                    <YAxis type="category" dataKey="name" hide />
                    <Bar dataKey="value" fill="#3b82f6" />
                    </BarChart>
                </ResponsiveContainer>
                {votingData.map((item, index) => (
                    <div key={index} className="voting-option">
                    <div className="option-name">
                        <div className={`color-dot color-${index + 1}`}></div>
                        <span>{item.name}</span>
                    </div>
                    <span>{item.percentage}%</span>
                    </div>
                ))}
                <div className="proposal-info">
                    <div>Status: <span className="status-completed">Completed</span></div>
                    <div>Created by: DLvz...qcWL</div>
                    <div>Start: 27 September 2024, 21:00 PM</div>
                    <div>End: 01 October 2024, 21:00 PM</div>
                </div>
                <div className="proposal-timeline">
                    <div className="timeline-item completed">
                    <Check size={16} />
                    <span>Created</span>
                    </div>
                    <div className="timeline-item completed">
                    <Check size={16} />
                    <span>Activated</span>
                    </div>
                    <div className="timeline-item completed">
                    <Check size={16} />
                    <span>Succeeded</span>
                    </div>
                    <div className="timeline-item">
                    <div className="timeline-dot"></div>
                    <span>Queued</span>
                    </div>
                    <div className="timeline-item">
                    <div className="timeline-dot"></div>
                    <span>Executed</span>
                    </div>
                </div>
                </div><div className="top-buttons">
                    <button onClick={connectWallet} className="button connect-wallet">
                    {isWalletConnected ? "Wallet Connected" : "Connect Wallet"}
                    </button>
                    <button onClick={handleAddProposal} className="button add-proposal">
                    Add Proposal
                    </button>
                </div>

            </div>
        </div>
    </div>
  );
};

export default GovernanceProposal;
