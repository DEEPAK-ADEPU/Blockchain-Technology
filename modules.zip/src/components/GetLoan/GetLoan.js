import React, { useState, useCallback } from 'react';
import './GetLoan.css';
import Header from '../Header/Header';
import Sidebar from '../Sidebar/Sidebar';

const LoanApplication = () => {
  const [loanAmount, setLoanAmount] = useState('');
  const [loanPurpose, setLoanPurpose] = useState('');
  const [employmentStatus, setEmploymentStatus] = useState('');
  const [loanHistory, setLoanHistory] = useState([
    { purpose: 'Home Loan', amount: '₹1,500,000', status: 'Approved' },
    { purpose: 'Car Loan', amount: '₹500,000', status: 'Paid' },
  ]);

  const handleSubmit = useCallback((e) => {
    e.preventDefault();
    console.log('Submitting loan application...');
    const newLoan = {
      purpose: loanPurpose,
      amount: `₹${Number(loanAmount).toLocaleString('en-IN')}`,
      status: 'Under Review'
    };
    setLoanHistory(prevHistory => {
      console.log('Updating loan history...', [newLoan, ...prevHistory]);
      return [newLoan, ...prevHistory];
    });
    console.log('Loan application submitted:', { loanAmount, loanPurpose, employmentStatus });
    setLoanAmount('');
    setLoanPurpose('');
    setEmploymentStatus('');
  }, [loanAmount, loanPurpose, employmentStatus]);

  const getDiscountInfo = () => {
    switch (employmentStatus) {
      case 'employed':
        return {
          title: "Employed Discount",
          description: "0.5% interest rate reduction for steady income earners."
        };
      case 'self-employed':
        return {
          title: "Self-Employed Bonus",
          description: "Flexible repayment options and 1% cashback on timely payments."
        };
      case 'unemployed':
        return {
          title: "New Start Program",
          description: "Extended grace period and financial counseling services."
        };
      case 'student':
        return {
          title: "Student Advantage",
          description: "No repayments until 6 months after graduation and 0.25% interest rate reduction."
        };
      default:
        return null;
    }
  };

  const discountInfo = getDiscountInfo();

  return (
    <div className='GetLoan-bg-container'>
      <Header />
            <div className='GetLoan-sub-bg-container'>
                <div className='Sidebar-container'>
                    <Sidebar />
                </div>
                <div className="loan-application-container">
                <div className="loan-form-card">
                    <h2 className="card-header">Loan Application</h2>
                    <div className="card-content">
                    <form onSubmit={handleSubmit} className="loan-form">
                        <div className="form-group">
                        <label htmlFor="loanAmount">Loan Amount</label>
                        <input
                            id="loanAmount"
                            type="number"
                            placeholder="Enter Loan Amount"
                            value={loanAmount}
                            onChange={(e) => setLoanAmount(e.target.value)}
                            required
                        />
                        </div>
                        <div className="form-group">
                        <label htmlFor="loanPurpose">Loan Purpose</label>
                        <input
                            id="loanPurpose"
                            type="text"
                            placeholder="Loan Purpose"
                            value={loanPurpose}
                            onChange={(e) => setLoanPurpose(e.target.value)}
                            required
                        />
                        </div>
                        <div className="form-group">
                        <label>Employment Status</label>
                        <div className="radio-group">
                            {['employed', 'self-employed', 'unemployed', 'student'].map((status) => (
                            <div key={status} className="radio-item">
                                <input
                                type="radio"
                                id={status}
                                value={status}
                                checked={employmentStatus === status}
                                onChange={() => setEmploymentStatus(status)}
                                />
                                <label htmlFor={status}>{status.charAt(0).toUpperCase() + status.slice(1)}</label>
                            </div>
                            ))}
                        </div>
                        </div>
                        {discountInfo && (
                        <div className="discount-alert">
                            <strong>{discountInfo.title}:</strong> {discountInfo.description}
                        </div>
                        )}
                        <button type="submit" className="submit-button">Apply for Loan</button>
                    </form>
                    </div>
                </div>

                <div className="loan-history-card">
                    <h2 className="card-header">Loan History</h2>
                    <div className="card-content">
                    <div className="loan-history-list">
                        {loanHistory.map((loan, index) => (
                        <div key={index} className="loan-history-item">
                            <span>{loan.purpose}</span>
                            <span>{loan.amount}</span>
                            <span className="loan-status">{loan.status}</span>
                        </div>
                        ))}
                    </div>
                    </div>
                </div>
                </div>
            </div> 
        <div/>
        
    </div>
  );
};

export default LoanApplication;