// src/App.js
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import './App.css';
import React from 'react';
import Dashboard from './components/Dashboard/Dashboard.js';
import Payment from './components/Payment/Payment.js';
import Governance from './components/Governance/Governance.js';
import Login from './components/Login/Login.js';
import Register from './components/Register/Register.js';
import ProposalDetails from './components/ProposalDetails/ProposalDetails.js';
import ProtectedRoute from './components/ProtectedRoute/ProtectedRoute.js'; 
import GetLoan from './components/GetLoan/GetLoan.js';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
        
          <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/payment" element={<ProtectedRoute><Payment /></ProtectedRoute>} />
          <Route path="/governance" element={<ProtectedRoute><Governance /></ProtectedRoute>} />
          <Route path="/GetLoan" element={<ProtectedRoute><GetLoan /></ProtectedRoute>} />
          <Route path="/governance/proposals" element={<ProtectedRoute><ProposalDetails /></ProtectedRoute>} />

          
          <Route path="*" element={<Navigate to="/login" />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
